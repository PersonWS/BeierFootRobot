﻿@echo off
set out=C:\Windows\SysWOW64
::复制当前路径所有文件和文件夹，至OUT路径文件夹
xcopy /y/e/c/h/z/r "%~pd0Comctl32.ocx" "%out%"

@echo off
set out=C:\Windows\SysWOW64
::复制当前路径所有文件和文件夹，至OUT路径文件夹
xcopy /y/e/c/h/z/r "%~pd0COMDLG32.OCX" "%out%"

@echo off
set out=C:\Windows\SysWOW64
::复制当前路径所有文件和文件夹，至OUT路径文件夹
xcopy /y/e/c/h/z/r "%~pd0mscomm32.ocx" "%out%"

@echo off
set out=C:\Windows\SysWOW64
::复制当前路径所有文件和文件夹，至OUT路径文件夹
xcopy /y/e/c/h/z/r "%~pd0mshflxgd.ocx" "%out%"





@echo off
set out=C:\Windows\System32
::复制当前路径所有文件和文件夹，至OUT路径文件夹
xcopy /y/e/c/h/z/r "%~pd0Comctl32.ocx" "%out%"

@echo off
set out=C:\Windows\System32
::复制当前路径所有文件和文件夹，至OUT路径文件夹
xcopy /y/e/c/h/z/r "%~pd0COMDLG32.OCX" "%out%"

@echo off
set out=C:\Windows\System32
::复制当前路径所有文件和文件夹，至OUT路径文件夹
xcopy /y/e/c/h/z/r "%~pd0mscomm32.ocx" "%out%"

@echo off
set out=C:\Windows\System32
::复制当前路径所有文件和文件夹，至OUT路径文件夹
xcopy /y/e/c/h/z/r "%~pd0mshflxgd.ocx" "%out%"


regsvr32 Comctl32.ocx
regsvr32 COMDLG32.OCX
regsvr32 mscomm32.ocx
regsvr32 mshflxgd.ocx

@echo off
set out=C:\Windows\System32
::复制当前路径所有文件和文件夹，至OUT路径文件夹
xcopy /y/e/c/h/z/r "%~pd0registery" "%out%"



@echo off
set out=C:\Windows\SysWOW64
::复制当前路径所有文件和文件夹，至OUT路径文件夹
xcopy /y/e/c/h/z/r "%~pd0registery" "%out%"
